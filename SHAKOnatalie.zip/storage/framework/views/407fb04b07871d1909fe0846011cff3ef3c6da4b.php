  
      <?php $__currentLoopData = getNews($site_category_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php 
         $newsthumblir = optional($news)->getThumbnail;
       ?>


            <div class="col-md-6 col-sm-12">
                <div class="what-is-new-insine">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="what-is-new-image">
                                <img src="<?php echo e(optional($newsthumblir)->url ?? noImage()); ?>">
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <div class="what-is-new-text">
                                <h3><?php echo e($news->TextTrans('title')); ?></h3>
                                <p><?php echo e($news->TextTrans('description')); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


