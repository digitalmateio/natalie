<!--
<div class="social-auth-links text-center">
    <p>- OR -</p>
    <a href="<?php echo e(url('/auth/github')); ?>" class="btn btn-block btn-social btn-github btn-flat"><i class="fa fa-github"></i> Sign in using Github</a>
    <a href="<?php echo e(url('/auth/facebook')); ?>" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-facebook"></i> Sign in using Facebook</a>
    <a href="<?php echo e(url('/auth/twitter')); ?>" class="btn btn-block btn-social btn-twitter btn-flat"><i class="fa fa-twitter"></i> Sign in using Twitter</a>
    <a href="<?php echo e(url('/auth/google')); ?>" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-google-plus"></i> Sign in using Google+</a>
</div>
-->