<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = getSlider(26); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e($image); ?>" alt="" width="200">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    
    
    
    

  <?php $__currentLoopData = getPartners(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <img src="<?php echo e($partner); ?>" alt="" width="200">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.main",['subMenu' => getSubMenu(3) ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>