<?php $__env->startSection('content'); ?>

<?php
	$sliderGet = getSlider(22);
	$ButtonsFr = true; 
	$ImagesFr = true; 
?>

<div id="carouselExampleIndicators" class="carousel slide main-head-slider" data-ride="carousel">
  <ol class="carousel-indicators">

    <?php $__currentLoopData = getSlider(22); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<?php if($ButtonsFr): ?>
	    	<li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($kay); ?>" class="active"></li>
	    	<?php echo e($ButtonsFr = false); ?> 
		<?php else: ?>
			<li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($kay); ?>" class=""></li>
		<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ol>
  <div class="carousel-inner">

    <?php $__currentLoopData = $sliderGet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($ImagesFr): ?>
		    <div class="carousel-item active">
		      <img class="d-block w-100" src="<?php echo e($image); ?>" alt="First slide">
		    </div>
		   <?php echo e($ImagesFr = false); ?> 
		<?php else: ?>
		    <div class="carousel-item ">
		      <img class="d-block w-100" src="<?php echo e($image); ?>" alt="First slide">
		    </div>
		<?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <i class="fas fa-arrow-left"></i>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <i class="fas fa-arrow-right"></i>
    <span class="sr-only">Next</span>
  </a>
</div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.main",['subMenu' => getSubMenu(null) ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>