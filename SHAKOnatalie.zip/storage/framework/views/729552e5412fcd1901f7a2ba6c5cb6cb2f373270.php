<?php if(!isset($no_padding)): ?>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Powered by <a href="<?php echo e(url('/')); ?>">S.S</a>
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y',time())); ?>

</footer>
<?php endif; ?>