<?php $__env->startSection('content'); ?>


    


<section>
    <div class="container beauty-head-blocks">

        <div class="row">

            <?php $__currentLoopData = $servicesCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php 
                 $thumblir = optional($serviceCategory)->getImage;
               ?>
                <!-- Line One -->
                <div class="col-md-2">
                    <div class="beauty-head-one-block">
                        <div class="beauty-image-block">
                            <a href="" class="image-hover-block">
                                <figure class="effect-apollo">
                                    <img src="<?php echo e(optional($thumblir)->url ?? noImage()); ?>">
                                    <figcaption><!--  --></figcaption>          
                                </figure>
                            </a>
                            <a href="<?php echo e(route('beautyCategory',$serviceCategory->id )); ?>" class="blocks-for-cat"><?php echo e($serviceCategory->TextTrans('title')); ?></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


    </div>
</section>



    
    
<section>
    <div class="container spa">

        <div class="row">
            <div class="col-md-10">
                <h2 class="section-title-head">WHATS NEW</h2>
            </div>
            <div class="col-md-2 float-right">
                <hr class="selction-title-right-side-line "></hr>
            </div>
        </div>



            
        <div class="row">

            <?php echo $__env->make('news', ['site_category_id' => 1], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        </div>



    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main",['subMenu' => getSubMenu(1) ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>