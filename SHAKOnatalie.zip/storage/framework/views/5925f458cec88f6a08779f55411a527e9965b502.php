<?php $__env->startSection('content'); ?>



			<?php if(!empty($pages['top section'])): ?>
			  	<?php $__currentLoopData = $pages['top section']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 	<?php

				 		$title = $page->TextTrans('title');
				 		$description = $page->TextTrans('description');
				        $image = optional($page)->getImage;

				 	?>

					<div class="academy-deah-image">
						<img src="<?php echo e(optional($image)->url); ?>">
					</div>

					<section>
						<div class="container">

							<div class="row">
								<div class="col-md-10">
									<h2 class="section-title-head">ABOUT ACADEMY</h2>
								</div>
							</div>

							<div class="row">
								
								<div class="col-md-12 academy-head-text">
									<p><?php echo e($description); ?></p>
								</div>

							</div>


						</div>
					</section>


				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>


			<?php if(!empty($pages['central section'])): ?>
			<section>
				<div class="container offers">

					<div class="row">
						<div class="col-md-10">
							<h2 class="section-title-head">OUR MISSION</h2>
						</div>
					</div>


					<div class="row">
					  	<?php $__currentLoopData = $pages['central section']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						 	<?php

						 		$title = $page->TextTrans('title');
						 		$description = $page->TextTrans('description');
						        $image = optional($page)->getImage;

						 	?>

								<div class="col-md-6">
									<div class="offers-one-block academy-mission-block">
										<div class="offers-image-block">
											<img src="<?php echo e(optional($image)->url); ?>">
										</div>
										<div class="offers-text-block">
											<p><?php echo e($description); ?></p>
										</div>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>

				</div>
			</section>

			<?php endif; ?>



			<?php if(!empty($teachers)): ?>
				<section>
					<div class="container products">

						<div class="row">
							<div class="col-md-10">
								<h2 class="section-title-head">TEACHERS</h2>
							</div>
						</div>

						<div class="row">
							<!-- Line One -->

						<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
						    $teacherImage = optional($teacher)->getImage;
						?>

					        <div class="col-md-2">
					        	<div class="products-one-block">
					        		<div class="products-image-block academy-teacher-img">
					        			<a href="">
					        				<img src="<?php echo e(optional($teacherImage)->url ?? noImage()); ?>">
					        				<p class="teacher-name"><?php echo e($teacher->TextTrans('name')); ?></p>
					        			</a>
					        		</div>
					        		<div class="products-text-info academy-teacher-text-block">
					        			<h3><?php echo e($teacher->TextTrans('specialist')); ?></h3>
					        			<p><?php echo e($teacher->TextTrans('description')); ?></p>
					        		</div>
					        	</div>
					        </div>
					        

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


						</div>

					</div>
				</section>
			<?php endif; ?>




			<?php if(!empty($courses)): ?>
			<section>
				<div class="container">

					<div class="row">
						<div class="col-md-10">
							<h2 class="section-title-head">COURSES</h2>
						</div>
					</div>

					<div class="row">
						<!-- Line One -->
					<?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php
					   $courseImage = optional($course)->getImage;

					?>

				        <div class="col-md-2">
				        	<div class="products-one-block">
				        		<div class="products-image-block academy-courses-img">
				        			<a href="">
				        				<img src="<?php echo e(optional($courseImage)->url ?? noImage()); ?>">
				        				<p class="courses-name"><?php echo e($course->TextTrans('title')); ?></p>
				        			</a>
				        		</div>
				        		<div class="products-text-info academy-courses-text-block">
				        			<a href="<?php echo e(route('AcademyCourse',$course->id)); ?>">view more</a>
				        		</div>
				        	</div>
				        </div>

				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



					</div>

				</div>
			</section>

			<?php endif; ?>




		<?php echo $__env->make('news', ['site_category_id' => 25], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main",['subMenu' => getSubMenu(2) ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>