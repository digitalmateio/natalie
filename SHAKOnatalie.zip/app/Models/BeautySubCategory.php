<?php
/**
 * Model genrated using LaraAdmin
 * Help: http://laraadmin.com
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BeautySubCategory extends Model
{
    use SoftDeletes;
	
	protected $table = 'beautysubcategories';
	
	protected $hidden = [
        
    ];

	protected $guarded = [];

	protected $dates = ['deleted_at'];
    
    public function category()
    {
       return $this->HasOne('App\Models\BeautyCategory','id','parent_category_id');
    }
    
    public function service()
    {  
        return $this->HasMany('App\Models\BeautyService','beautysubcategory_id','id');
    }
}
