<?php
/**
 * Model genrated using LaraAdmin
 * Help: http://laraadmin.com
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BeautyCategory extends Model
{
    use SoftDeletes;
	
	protected $table = 'beautycategories';
	
	protected $hidden = [
        
    ];

	protected $guarded = [];

	protected $dates = ['deleted_at'];
    
    public function subCategories()
    { 
        return $this->HasMany('App\Models\BeautySubCategory','parent_category_id','id');
    }
    
    public function getImage()
    {
        return $this->belongsTo('App\Models\Upload','image','id'); 
    }
}
