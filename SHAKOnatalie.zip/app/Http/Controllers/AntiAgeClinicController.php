<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Page_generator;
use App\Models\ServiceCategory;
use App\Models\ServiceSubCategory;


class AntiAgeClinicController extends Controller
{
    public function main()
    {
        $pages = Page_generator::where('page_id',26)->get();

        return view('AntiAgeClinic.main',[
           'pages' => $pages, 
        ]);
    }
    
    public function skincare()
    {
        $servicesCategories = ServiceCategory::where('site_category_id',3)->get();
        return view('AntiAgeClinic.skincare',[
            'servicesCategories' => $servicesCategories,
        ]);

    }
    
    public function  bodycare()
    {
        return view('bodycare');
    }
    
    public function  laser()
    {

    }
    
    public function  products()
    {

    }
    
    public function  contact()
    {

    }
    
    public function category(int $id = null)
    {
        $ServiceCategory = ServiceCategory::find($id);
        $ServiceSubCategories = ServiceSubCategory::where('parent_category_id',$id)->get();
        $servicesArray = [];
        
        foreach($ServiceSubCategories as $ServiceSubCategory)
        {
            $services = $ServiceSubCategory->service;
            foreach($services as $service)
            {
                if(in_array("standart", $service->service_type))
                {
                    $servicesArray['standart'][$ServiceSubCategory->TextTrans('title')] = [
                        'service_title' => $service->TextTrans('title'),
                        'price' => $service->price,
                        'subCategoryTitle' => $ServiceSubCategory->TextTrans('title')
                    ];
                }
                
                if(in_array("premium", $service->service_type))
                {
                    $servicesArray['premium'][$ServiceSubCategory->TextTrans('title')] = [
                        'service_title' => $service->TextTrans('title'),
                        'price' => $service->price,
                        'subCategoryTitle' => $ServiceSubCategory->TextTrans('title')
                    ];
                }
                
                if(!in_array("standart", $service->service_type) && !in_array("premium", $service->service_type) )
                {
                    $servicesArray[] = [
                        'service_title' => $service->TextTrans('title'),
                        'price' => $service->price,
                        'subCategoryTitle' => $ServiceSubCategory->TextTrans('title')
                    ];
                }     
            }
        }
        
        return view('AntiAgeClinic.services',[
           'ServiceCategory' => $ServiceCategory,
           'ServiceSubCategories' => $ServiceSubCategories,
           'servicesArray' => $servicesArray,
       ]); 
        
    }
}
