<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceCategory;
use App\Models\Page_generator;
use App\Models\ServiceSubCategory;

class NatalieSpaController extends Controller
{
    public function main()
    {
        $servicesCategories = ServiceCategory::where('site_category_id',6)->get();
        $pages = Page_generator::where('page_id',29)->get();

        return view('NataliSpa.main',[
            'servicesCategories' => $servicesCategories,
            'pages' => $pages,
        ]);
    }
    
      public function category(int $id = null)
    {
        $ServiceSubCategories = ServiceSubCategory::where('parent_category_id',$id)->get();
        $servicesArray = [];
    
        foreach($ServiceSubCategories as $ServiceSubCategory)
        {
            $services = $ServiceSubCategory->service;
            foreach($services as $service)
            {
                if(in_array("standart", $service->service_type))
                {
                    $servicesArray['standart'][$ServiceSubCategory->TextTrans('title')] = [
                        'service_title' => $service->TextTrans('title'),
                        'price' => $service->price,
                        'subCategoryTitle' => $ServiceSubCategory->TextTrans('title')
                    ];
                }
                
                if(in_array("premium", $service->service_type))
                {
                    $servicesArray['premium'][$ServiceSubCategory->TextTrans('title')] = [
                        'service_title' => $service->TextTrans('title'),
                        'price' => $service->price,
                        'subCategoryTitle' => $ServiceSubCategory->TextTrans('title')
                    ];
                }
                
                if(!in_array("standart", $service->service_type) && !in_array("premium", $service->service_type) )
                {
                    $servicesArray[] = [
                        'service_title' => $service->TextTrans('title'),
                        'price' => $service->price,
                        'subCategoryTitle' => $ServiceSubCategory->TextTrans('title')
                    ];
                }
            }
        }
  
       return view('NataliSpa.services',[
           'ServiceSubCategories' => $ServiceSubCategories,
           'servicesArray' => $servicesArray,
       ]);  
    }
    
    
}
